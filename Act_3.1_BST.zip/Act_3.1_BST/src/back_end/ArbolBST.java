/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;

/**
 *
 * @author coter
 */
public class ArbolBST {
    private NodoBST raiz;
    
    public ArbolBST() {
        this.raiz = null;
    }

//insertar(Empleado empleado): 
    public void insertar(Empleado empleado) { // metodo "Publico"
        if (empleado == null) {
            throw new IllegalArgumentException("ERROR: El empleado no puede ser nulo");
        }
        if (buscar(empleado.getId()) != null) { //si se repite el mismo
            throw new IllegalArgumentException("ERROR: El ID " + empleado.getId() + " ya existe(esta duplicado)");
        }
        raiz = insertarRec(raiz, empleado);
    }
    private NodoBST insertarRec(NodoBST nodo, Empleado empleado) {//"Recursiva"
        if (nodo == null) {
            return new NodoBST(empleado);
        }
        if (empleado.getId() < nodo.getDato().getId()) {
            nodo.setIzquierdo(insertarRec(nodo.getIzquierdo(), empleado));
        } else {
            nodo.setDerecho(insertarRec(nodo.getDerecho(), empleado));
        }
        return nodo;
    }
    
//eliminar(Integer id):
   public void eliminar(Integer id) { // metodo "Publico"
        if (id == null) {
            throw new IllegalArgumentException("ERROR: El ID no puede ser nulo.");
        }
        if (raiz == null) {
            throw new IllegalArgumentException("ERROR: El árbol está vacío, no hay empleados que eliminar");
        }
        if (buscar(id) == null) {
            throw new IllegalArgumentException("ERROR: No se encontró empleado con ID " + id + ".");
        }
        raiz = eliminarRec(raiz, id);
    }

    private NodoBST eliminarRec(NodoBST nodo, Integer id) { //"Recursiva"
        if (nodo == null) {
            return null;
        }
        if (id < nodo.getDato().getId()) {
            nodo.setIzquierdo(eliminarRec(nodo.getIzquierdo(), id));
        } else if (id > nodo.getDato().getId()) {
            nodo.setDerecho(eliminarRec(nodo.getDerecho(), id));
        } else {
            if (nodo.getIzquierdo() == null && nodo.getDerecho() == null) {// Caso 1: hoja
                return null;
            }
            if (nodo.getIzquierdo() == null) { // Caso 2: un solo hijo (el derecho)
                return nodo.getDerecho();
            }
            if (nodo.getDerecho() == null) { // Caso 2: un solo hijo (el izquierdo)
                return nodo.getIzquierdo();
            }
            NodoBST sucesor = minimo(nodo.getDerecho());// Caso 3: dos hijos -> sucesor inorden
            nodo.setDato(sucesor.getDato());
            nodo.setDerecho(eliminarRec(nodo.getDerecho(), sucesor.getDato().getId()));
        }
        return nodo;
    }

    private NodoBST minimo(NodoBST nodo) { // Para buscar un sucesor si hay 2 hijos
        while (nodo.getIzquierdo() != null) {
            nodo = nodo.getIzquierdo();
        }
        return nodo;
    }
 
//buscar(Integer id): 
    public Empleado buscar(Integer id) {  // metodo "Publico"
        if (id == null) return null;
        return buscarRec(raiz, id);
    }

    private Empleado buscarRec(NodoBST nodo, Integer id) { //"Recursiva"
        if (nodo == null) {
            return null;
        }
        if (id.equals(nodo.getDato().getId())) {
            return nodo.getDato();
        }
        if (id < nodo.getDato().getId()) {
            return buscarRec(nodo.getIzquierdo(), id);
        } else {
            return buscarRec(nodo.getDerecho(), id);
        }
    }
//mostrarInOrden(): 
    public String mostrarInOrden() { // metodo "Publico"
        StringBuilder sb = new StringBuilder();
        inOrdenRec(raiz, sb);
        return sb.toString();
    }
 
    private void inOrdenRec(NodoBST nodo, StringBuilder sb) { //"Recursiva"
        if (nodo == null) return;
        inOrdenRec(nodo.getIzquierdo(), sb);
        sb.append(nodo.getDato()).append("\n");
        inOrdenRec(nodo.getDerecho(), sb);
    }
    
// mostrarPreOrden(): 
    public String mostrarPreOrden() { // metodo "Publico"
        StringBuilder sb = new StringBuilder();
        preOrdenRec(raiz, sb);
        return sb.toString();
    }

    private void preOrdenRec(NodoBST nodo, StringBuilder sb) { //"Recursiva"
        if (nodo == null) return;
        sb.append(nodo.getDato()).append("\n");
        preOrdenRec(nodo.getIzquierdo(), sb);
        preOrdenRec(nodo.getDerecho(), sb);
    }
    
//mostrarPostOrden(): 
    public String mostrarPostOrden() { // metodo "Publico"
        StringBuilder sb = new StringBuilder();
        postOrdenRec(raiz, sb);
        return sb.toString();
    }

    private void postOrdenRec(NodoBST nodo, StringBuilder sb) { //"Recursiva"
        if (nodo == null) return;
        postOrdenRec(nodo.getIzquierdo(), sb);
        postOrdenRec(nodo.getDerecho(), sb);
        sb.append(nodo.getDato()).append("\n");
    }
    
//amplitud(): 
    public int amplitud() {
        if (raiz == null) return 0;
        NodoBST[] cola = new NodoBST[1000];
        int frente = 0, fin = 0;
        cola[fin++] = raiz;
        int maxNodos = 0;

        while (frente < fin) {
            int nodosNivel = fin - frente;
            maxNodos = Math.max(maxNodos, nodosNivel);
            int finNivel = fin;
            while (frente < finNivel) {
                NodoBST actual = cola[frente++];
                if (actual.getIzquierdo() != null) cola[fin++] = actual.getIzquierdo();
                if (actual.getDerecho() != null) cola[fin++] = actual.getDerecho();
            }
        }
        return maxNodos;
    }
    
//profundidad():
     public int profundidad() { // metodo "Publico"
        return profundidadRec(raiz);
    }

    private int profundidadRec(NodoBST nodo) { //"Recursiva"
        if (nodo == null) return 0;
        int izq = profundidadRec(nodo.getIzquierdo());
        int der = profundidadRec(nodo.getDerecho());
        return 1 + Math.max(izq, der);
    }
    
//balancear(): 
    public void balancear() {  // metodo "Publico"
        int n = contarNodos();
        Empleado[] ordenados = new Empleado[n];
        int[] indice = {0};
        llenarInOrden(raiz, ordenados, indice);
        raiz = construirBalanceado(ordenados, 0, n - 1);
    }

    private void llenarInOrden(NodoBST nodo, Empleado[] arr, int[] indice) { //"Recursiva"
        if (nodo == null) return;
        llenarInOrden(nodo.getIzquierdo(), arr, indice);
        arr[indice[0]++] = nodo.getDato();
        llenarInOrden(nodo.getDerecho(), arr, indice);
    }

    private NodoBST construirBalanceado(Empleado[] arr, int ini, int fin) {
        if (ini > fin) return null;
        int medio = (ini + fin) / 2;
        NodoBST nodo = new NodoBST(arr[medio]);
        nodo.setIzquierdo(construirBalanceado(arr, ini, medio - 1));
        nodo.setDerecho(construirBalanceado(arr, medio + 1, fin));
        return nodo;
    }
    
//destruirArbol(): 
    public void destruirArbol() {
        raiz = null;
    }
    
//metodo para contar los nodos
    public int contarNodos() { // metodo "Publico"
        return contarRec(raiz);
    }

    private int contarRec(NodoBST nodo) { //"Recursiva"
        if (nodo == null) return 0;
        return 1 + contarRec(nodo.getIzquierdo()) + contarRec(nodo.getDerecho());
    }
//Metodo para actualizar (no dice en la estructura pero en el inicio de las instrucciones si)
   public void actualizar(Integer id, Empleado nuevosDatos) { // metodo "Publico"
        if (id == null) {
            throw new IllegalArgumentException("ERROR: El ID no puede ser nulo.");
        }
        if (nuevosDatos == null) {
            throw new IllegalArgumentException("ERROR: Los datos del empleado no pueden ser nulos.");
        }
        if (raiz == null) {
            throw new IllegalArgumentException("ERROR: El árbol está vacío, no hay empleados que actualizar.");
        }
        if (buscar(id) == null) { // reutiliza buscar y se ahorra eso
            throw new IllegalArgumentException("ERROR: No se encontró empleado con ID " + id + ".");
        }
        if (!id.equals(nuevosDatos.getId())) {
            throw new IllegalArgumentException("ERROR: El ID no se puede modificar (es la clave del árbol).");
        }
        reemplazarDato(raiz, id, nuevosDatos);
    }

    private void reemplazarDato(NodoBST nodo, Integer id, Empleado nuevos) { //"Recursiva"
        if (nodo == null) return;
        if (id.equals(nodo.getDato().getId())) {
            nodo.setDato(nuevos);
            return;
        }
        if (id < nodo.getDato().getId()) {
            reemplazarDato(nodo.getIzquierdo(), id, nuevos);
        } else {
            reemplazarDato(nodo.getDerecho(), id, nuevos);
        }
    } 
}//final
